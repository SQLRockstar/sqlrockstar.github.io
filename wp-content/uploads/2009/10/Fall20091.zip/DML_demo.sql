--DML example
USE AdventureWorks;
GO
--if exists, then drop
IF OBJECT_ID ('Sales.reminder1', 'TR') IS NOT NULL
   DROP TRIGGER Sales.reminder1;
GO

--create trigger
CREATE TRIGGER reminder1
ON Sales.Customer
AFTER INSERT, UPDATE 
AS RAISERROR ('Notify Customer Relations', 16, 10);
GO

--look at some data
SELECT * FROM [AdventureWorks].[Sales].[Customer] WHERE [CustomerID]= 29483

--try to update data
UPDATE [AdventureWorks].[Sales].[Customer]
   SET [CustomerType] = 'I'
 WHERE [CustomerID]= 29483
GO

--did update succeed?
SELECT * FROM [AdventureWorks].[Sales].[Customer] WHERE [CustomerID]= 29483


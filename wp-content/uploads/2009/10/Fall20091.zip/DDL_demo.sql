--example that creates trigger on database that prevents tables
--from being dropped or altered

--use correct db
USE AdventureWorks
GO

CREATE TRIGGER safety 
ON DATABASE 
FOR DROP_TABLE, ALTER_TABLE 
AS 
   PRINT 'You must disable Trigger "safety" to drop or alter tables!' 
   ROLLBACK ;

--try to drop a table
DROP TABLE ErrorLog
GO

--try to alter table
ALTER TABLE dbo.ErrorLog ADD
	col1 nchar(10) NULL
GO

--try to create a table
CREATE TABLE [dbo].[test](
	[test] [nchar](10) NULL
) ON [PRIMARY]

GO

--try dropping that table
DROP TABLE test
GO

--drop trigger
DROP TRIGGER safety
ON DATABASE
GO

--try dropping that table
DROP TABLE test
GO
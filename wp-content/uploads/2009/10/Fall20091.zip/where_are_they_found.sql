USE AdventureWorks
GO

--inside the sysobjects for a particular database
SELECT * FROM sys.objects WHERE type = 'TR'
GO

--what about system views?
SELECT * FROM sys.triggers
GO

--not very friendly, so we try
SELECT name, OBJECT_NAME(parent_id) as [Parent Object], is_disabled FROM sys.triggers
GO

--still not enough!
--for server scoped DDL and logon triggers 
SELECT name, OBJECT_NAME(object_id), is_disabled
FROM sys.server_triggers
GO

--compare this to how it is even more difficult to locate
--triggers inside of SSMS



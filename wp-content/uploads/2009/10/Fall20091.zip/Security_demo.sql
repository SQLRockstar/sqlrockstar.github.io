--create the trigger
CREATE TRIGGER TR_ImpPersonalData_reminder
ON ImpPersonalData
AFTER INSERT, UPDATE, DELETE 
AS
	--you would probably want to log details to a table and not flood your SMTP server
   EXEC msdb.dbo.sp_send_dbmail        
   @profile_name = 'Customer Data Manager',        
   @recipients = 'donotemailme@anytime.com',        
   @body = 'Customer data has been modified.',        
   @subject = 'Modification made!';
GO

--this is also for security purposes
CREATE TRIGGER TR_DoNotDeleteMe 
ON DATABASE
FOR DROP_TABLE, ALTER_TABLE 
AS 
PRINT 'You are not allowed to drop or alter tables!' 
   ROLLBACK ;


